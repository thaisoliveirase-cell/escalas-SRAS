import { useState } from "react";

const CARGOS=["Médico(a) Regulador(a)","Enfermeiro(a)","Técnico(a) de Enfermagem","Auxiliar de Enfermagem","Assistente Administrativo"];
const SETORES=["SRAS","Regulação","UTI","Pronto-Socorro","Internação","CME"];
const VINCULOS=["CLT/EBSERH","UFS","Residente","Outros"];
const CH_OPTS=["18h","20h","21h","24h","30h","36h","40h"];
const MESES=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

const SC={
  "M":  {bg:"#dbeafe",text:"#1d4ed8",label:"Manhã (M15)"},
  "T":  {bg:"#dcfce7",text:"#15803d",label:"Tarde (T15)"},
  "D":  {bg:"#fef9c3",text:"#854d0e",label:"Plant.Dia 12h"},
  "N":  {bg:"#ede9fe",text:"#6d28d9",label:"Plant.Noite 12h"},
  "FE": {bg:"#bbf7d0",text:"#15803d",label:"Férias"},
  "D6": {bg:"#f1f5f9",text:"#94a3b8",label:"DSR/Folga"},
  "F":  {bg:"#fee2e2",text:"#b91c1c",label:"Falta/Atestado"},
  "FL": {bg:"#ffedd5",text:"#c2410c",label:"Folga Comp."},
  "LM": {bg:"#fce7f3",text:"#9d174d",label:"Lic.Maternidade"},
  "AB": {bg:"#fef3c7",text:"#92400e",label:"Abono"},
  "CH": {bg:"#fde68a",text:"#b45309",label:"Comp.Horas"},
  "AF": {bg:"#e9d5ff",text:"#7c3aed",label:"Afastamento"},
  "LC": {bg:"#dbeafe",text:"#1e40af",label:"Lic.Capacitação"},
  "LP": {bg:"#dbeafe",text:"#1d4ed8",label:"Lic.Paternidade"},
  "L":  {bg:"#fee2e2",text:"#b91c1c",label:"Lic.Médica"},
  "RC": {bg:"#f1f5f9",text:"#475569",label:"Recesso"},
  "CP": {bg:"#e0f2fe",text:"#0369a1",label:"C.Própria"},
  "CD": {bg:"#f3e8ff",text:"#7c3aed",label:"C.Dep."},
  "RB": {bg:"#dcfce7",text:"#166534",label:"Reabilitação"},
  "PV": {bg:"#cffafe",text:"#0e7490",label:"Preventivo"},
  "FA": {bg:"#fce7f3",text:"#9d174d",label:"Aniversário"},
  "AT": {bg:"#fff7ed",text:"#c2410c",label:"Atraso"},
  "":   {bg:"#f8fafc",text:"#cbd5e1",label:"-"},
};
const TODOS_CODIGOS=Object.keys(SC).filter(k=>k);

const ACT_TIPOS=[
  {grupo:"📋 Afastamentos ACT EBSERH",itens:[
    {key:"act_abono",   label:"⭐ Abono de Ponto",      code:"AB",cor:"#fef3c7",corT:"#92400e",regra:"2 abonos anuais. Avisar chefia com 15 dias (ACT Cl.25).",limiteAno:2, limiteMes:null,precisaDoc:false},
    {key:"act_cp",      label:"🩺 Consulta própria",    code:"CP",cor:"#e0f2fe",corT:"#0369a1",regra:"2 meios períodos/mês para consultas próprias (ACT).",limiteAno:null,limiteMes:2, precisaDoc:true},
    {key:"act_cd",      label:"👨‍👩‍👧 Consulta dependente",code:"CD",cor:"#f3e8ff",corT:"#7c3aed",regra:"4 meios períodos/mês para dependentes (ACT).",limiteAno:null,limiteMes:4, precisaDoc:true},
    {key:"act_rb",      label:"🏃 Reabilitação",         code:"RB",cor:"#dcfce7",corT:"#166534",regra:"Até 30 meios períodos/ano, máx. 5/mês (ACT Cl.35).",limiteAno:30,limiteMes:5, precisaDoc:true},
    {key:"act_int_dep", label:"🏥 Internação dependente",code:"ID",cor:"#fff7ed",corT:"#c2410c",regra:"Até 15 dias/ano (ACT). Exige declaração médica.",limiteAno:15,limiteMes:null,precisaDoc:true},
    {key:"act_prev",    label:"🔬 Preventivo anual",     code:"PV",cor:"#cffafe",corT:"#0e7490",regra:"1 consulta preventiva/ano. Exige comprovante (ACT).",limiteAno:1, limiteMes:null,precisaDoc:true},
    {key:"act_aniv",    label:"🎂 Folga Aniversário",    code:"FA",cor:"#fce7f3",corT:"#9d174d",regra:"1 dia no mês do aniversário (ACT Cl.26).",limiteAno:1, limiteMes:null,precisaDoc:false},
  ]},
  {grupo:"📁 Ocorrências Gerais",itens:[
    {key:"atestado",label:"📄 Atestado Médico",    code:"F", cor:"#fee2e2",corT:"#b91c1c",regra:"Entregar em até 5 dias úteis.",limiteAno:null,limiteMes:null,precisaDoc:true},
    {key:"falta",   label:"❌ Falta Injustificada",code:"F", cor:"#fee2e2",corT:"#b91c1c",regra:"Registro de falta não justificada.",limiteAno:null,limiteMes:null,precisaDoc:false},
    {key:"atraso",  label:"⏰ Atraso",             code:"AT",cor:"#fff7ed",corT:"#c2410c",regra:"Informar motivo e estimativa.",limiteAno:null,limiteMes:null,precisaDoc:false},
    {key:"troca",   label:"🔄 Troca de Plantão",   code:null,cor:"#eff6ff",corT:"#1d4ed8",regra:"Ambos concordam. Mesma categoria. Gestor aprova.",limiteAno:null,limiteMes:null,precisaDoc:false},
    {key:"folga",   label:"🌙 Folga Compensatória",code:"FL",cor:"#ffedd5",corT:"#c2410c",regra:"Folga por trabalho em dia não útil.",limiteAno:null,limiteMes:null,precisaDoc:false},
    {key:"ferias",  label:"✈️ Férias",             code:"FE",cor:"#bbf7d0",corT:"#15803d",regra:"Comunicar com 60 dias de antecedência.",limiteAno:null,limiteMes:null,precisaDoc:false},
    {key:"lic_mat", label:"👶 Licença Maternidade", code:"LM",cor:"#fce7f3",corT:"#9d174d",regra:"180 dias (ACT Cl.30).",limiteAno:null,limiteMes:null,precisaDoc:true},
  ]},
];
const TODOS_TIPOS=ACT_TIPOS.flatMap(g=>g.itens);

function getDIM(m,y){return new Date(y,m+1,0).getDate();}
function getDOW(d,m,y){return new Date(y,m,d).getDay();}
function getDL(d,m,y){return ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"][getDOW(d,m,y)];}

// ── Profissionais pré-cadastrados ────────────────────────────────────────────
const PROFS_INIT=[
  // Médicos
  {id:"med001",nome:"Adriana Barbosa de Lima Fonseca",  cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"UFS",       ch:"18h",bh:""},
  {id:"med002",nome:"Amanda Ferreira de Brito Caldas",  cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"21h",bh:""},
  {id:"med003",nome:"Claudia Patrícia Souza Teles",     cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"18h",bh:""},
  {id:"med004",nome:"Crislaine Jesus Silvino Bezerra",  cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"24h",bh:""},
  {id:"med005",nome:"Eline Vieira Cruz de Andrade",     cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"24h",bh:""},
  {id:"med006",nome:"Keila Ribeiro Villar Gouy",        cargo:"Médico(a) Regulador(a)",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"24h",bh:""},
  // Enfermeiros
  {id:"enf001",nome:"Jackeline Melo Santana",           cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"3034647",registro:"268250",vinculo:"CLT/EBSERH",ch:"36h",bh:"-024:28"},
  {id:"enf002",nome:"Victor Souza de Matos",            cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"2149180",registro:"245533",vinculo:"CLT/EBSERH",ch:"36h",bh:""},
  {id:"enf003",nome:"Leonardo Rodrigues dos Santos",    cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"1242342",registro:"174898",vinculo:"CLT/EBSERH",ch:"36h",bh:"-000:33"},
  {id:"enf004",nome:"Hadassa Souza Vieira",             cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"3034055",registro:"156907",vinculo:"CLT/EBSERH",ch:"36h",bh:"-025:03"},
  {id:"enf005",nome:"Neyana Maria Coelho de Souza",     cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"1104047",registro:"390844",vinculo:"CLT/EBSERH",ch:"36h",bh:"000:00"},
  {id:"enf006",nome:"Maria Regivalda Santana de S.",    cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"1106102",registro:"393861",vinculo:"CLT/EBSERH",ch:"36h",bh:"-000:05"},
  {id:"enf007",nome:"Ilze Mariane Oliveira Matos",      cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"3048557",registro:"268649",vinculo:"CLT/EBSERH",ch:"36h",bh:"000:34"},
  {id:"enf008",nome:"Joyce Francielle Nei Bomfim",      cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"2764024",registro:"275490",vinculo:"CLT/EBSERH",ch:"36h",bh:"-088:15"},
  {id:"enf009",nome:"Jacqueline Cunha Cabral Azevedo",  cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"2149083",registro:"154200",vinculo:"CLT/EBSERH",ch:"36h",bh:"-021:48"},
  {id:"enf010",nome:"Nandiara Figueiredo Araujo",       cargo:"Enfermeiro(a)",setor:"SRAS",siape:"",matricula:"3257704",registro:"528093",vinculo:"CLT/EBSERH",ch:"36h",bh:"-039:23"},
  // Técnicos de Enfermagem (SIGP maio/2026 v4)
  {id:"tec001",nome:"Valeria Cristina Santos",          cargo:"Técnico(a) de Enfermagem",setor:"SRAS",siape:"",matricula:"2290044",registro:"COREN/SE 303404 TE",vinculo:"CLT/EBSERH",ch:"36h",bh:"027:59"},
  {id:"tec002",nome:"Maria Elizangela da Silva",        cargo:"Técnico(a) de Enfermagem",setor:"SRAS",siape:"",matricula:"2149134",registro:"146647",vinculo:"CLT/EBSERH",ch:"36h",bh:"-049:45"},
  {id:"tec003",nome:"Cristiane Dias Vaccari",           cargo:"Técnico(a) de Enfermagem",setor:"SRAS",siape:"",matricula:"2158958",registro:"509529",vinculo:"CLT/EBSERH",ch:"36h",bh:"-019:01"},
  // Auxiliar de Enfermagem
  {id:"aux001",nome:"Ione Farias de Lima",              cargo:"Auxiliar de Enfermagem",setor:"SRAS",siape:"",matricula:"",registro:"",cpf:"99142238121",vinculo:"RJU",ch:"30h",bh:"",turno:"Plantão Noturno 12x60"},
  // Assistentes Administrativos
  {id:"adm001",nome:"Patricia Silva Passos",            cargo:"Assistente Administrativo",setor:"SRAS",siape:"",matricula:"2166394",registro:"",vinculo:"CLT/EBSERH",ch:"40h",bh:"",turno:"Seg-Sex 8h"},
  {id:"adm002",nome:"Amanda Barreto Silva",             cargo:"Assistente Administrativo",setor:"SRAS",siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"40h",bh:"",turno:"Seg-Sex 8h"},
];

function buildEscalaInicial(){
  const e={};
  const mes=5,ano=2026,dias=getDIM(mes,ano);
  // Médicos (SEI)
  const medRegras={
    med001:[{dow:1,t:"M"},{dow:1,t:"T2"},{dow:4,t:"M"},{dow:4,t:"T2"}],
    med002:[{dow:3,t:"M"},{dow:3,t:"T2"},{dow:5,t:"M"},{dow:5,t:"T2"}],
    med003:[{dow:1,t:"T2"},{dow:4,t:"M"},{dow:4,t:"T2"}],
    med004:[{dow:2,t:"M"}],
    med005:[{dow:2,t:"M"}],
    med006:[{dow:2,t:"M"},{dow:2,t:"T2"},{dow:3,t:"M"},{dow:3,t:"T2"},{dow:5,t:"M"},{dow:5,t:"T2"}],
  };
  Object.entries(medRegras).forEach(([id,rules])=>{
    const pd={};
    rules.forEach(({dow,t})=>{if(!pd[dow])pd[dow]=[];pd[dow].push(t);});
    for(let d=1;d<=dias;d++){
      const dow=getDOW(d,mes,ano);
      if(pd[dow]){
        if(pd[dow].some(t=>t==="M"))   e[`${id}_${d}_m`]="M";
        if(pd[dow].some(t=>t==="T2"))  e[`${id}_${d}_t`]="T";
      }
    }
  });
  // Enfermeiros (SIGP)
  const enf={
    enf001:{1:"D",2:"M",3:"M",4:"M",5:"M",6:"D6",7:"D6",8:"D",9:"M",10:"M",11:"M",12:"M",13:"D6",14:"D6",15:"D",16:"M",17:"M",18:"M",19:"M",20:"D6",21:"D6",22:"D",23:"M",24:"M",25:"M",26:"M",27:"D6",28:"D6",29:"D",30:"M"},
    enf002:{1:"M",2:"M",3:"M",4:"M",5:"M",6:"D6",7:"D6",8:"D",9:"M",10:"M",11:"M",12:"M",13:"D6",14:"D6",15:"M",16:"M",17:"M",18:"M",19:"M",20:"D6",21:"D6",22:"M",23:"M",24:"M",25:"M",26:"M",27:"D6",28:"D6",29:"M",30:"M"},
    enf003:{1:"M",2:"M",3:"M",4:"M",5:"M",6:"D6",7:"D6",8:"M",9:"M",10:"M",11:"M",12:"M",13:"D6",14:"D6",15:"M",16:"M",17:"M",18:"M",19:"M",20:"FE",21:"FE",22:"FE",23:"FE",24:"FE",25:"FE",26:"FE",27:"FE",28:"FE",29:"FE",30:"FE"},
    enf004:{1:"",2:"M",3:"M",4:"M",5:"",6:"D6",7:"D6",8:"FE",9:"FE",10:"FE",11:"FE",12:"FE",13:"FE",14:"FE",15:"FE",16:"M",17:"FE",18:"FE",19:"FE",20:"FE",21:"FE",22:"FE",23:"M",24:"M",25:"",26:"M",27:"D6",28:"D6",29:"M",30:"M"},
    enf005:{1:"M",2:"M",3:"M",4:"M",5:"D6",6:"D6",7:"D6",8:"M",9:"M",10:"M",11:"M",12:"M",13:"D6",14:"D6",15:"M",16:"M",17:"M",18:"M",19:"M",20:"D6",21:"D6",22:"M",23:"M",24:"M",25:"M",26:"M",27:"D6",28:"D6",29:"M",30:"M"},
    enf006:{1:"M",2:"M",3:"M",4:"M",5:"M",6:"D6",7:"D6",8:"M",9:"M",10:"M",11:"M",12:"M",13:"D6",14:"D6",15:"M",16:"M",17:"M",18:"M",19:"M",20:"D6",21:"D6",22:"M",23:"M",24:"M",25:"M",26:"M",27:"D6",28:"D6",29:"M",30:"M"},
    enf007:{1:"T",2:"T",3:"T",4:"T",5:"T",6:"T",7:"D6",8:"T",9:"FE",10:"FE",11:"FE",12:"FE",13:"FE",14:"FE",15:"T",16:"T",17:"T",18:"T",19:"T",20:"T",21:"D6",22:"T",23:"T",24:"T",25:"T",26:"T",27:"T",28:"D6",29:"T",30:"T"},
    enf008:{1:"T",2:"T",3:"T",4:"T",5:"T",6:"D6",7:"D6",8:"T",9:"T",10:"T",11:"T",12:"T",13:"D6",14:"D6",15:"T",16:"D",17:"T",18:"T",19:"T",20:"T",21:"D6",22:"T",23:"T",24:"T",25:"D6",26:"T",27:"D6",28:"D6",29:"T",30:"T"},
    enf009:{1:"T",2:"T",3:"T",4:"T",5:"T",6:"D6",7:"D6",8:"T",9:"T",10:"T",11:"T",12:"T",13:"D6",14:"D6",15:"T",16:"T",17:"T",18:"T",19:"T",20:"D6",21:"D6",22:"T",23:"T",24:"T",25:"T",26:"T",27:"D6",28:"D6",29:"T",30:"T"},
    enf010:{1:"T",2:"T",3:"T",4:"T",5:"T",6:"D6",7:"D6",8:"T",9:"T",10:"T",11:"T",12:"T",13:"D6",14:"D6",15:"T",16:"T",17:"T",18:"T",19:"T",20:"D6",21:"D6",22:"T",23:"T",24:"T",25:"D6",26:"T",27:"D6",28:"D6",29:"T",30:"T"},
  };
  Object.entries(enf).forEach(([id,diasMap])=>{
    Object.entries(diasMap).forEach(([d,code])=>{
      if(code) e[`${id}_${d}_m`]=code;
    });
  });

  // Tecnicos de Enfermagem - escala lida da imagem SIGP maio/2026
  // Junho 2026: 1=Seg,2=Ter,3=Qua,4=Qui,5=Sex,6=Sáb,7=Dom,8=Seg,9=Ter,10=Qua,
  //             11=Qui,12=Sex,13=Sáb,14=Dom,15=Seg,16=Ter,17=Qua,18=Qui,19=Sex,
  //             20=Sáb,21=Dom,22=Seg,23=Ter,24=Qua,25=Qui,26=Sex,27=Sáb,28=Dom,29=Seg,30=Ter
  // Valeria: M15 dias úteis, D6 intercalados (padrão semanal extraído)
  // Maria Elizangela: M13 Qua/Sex alternado, D6 intercalado
  // Cristiane: T15 Ter a Sex, AF dia 4 maio→sem AF em junho, padrão T15
  const tecEscalas={
    tec001:{
      1:"M",2:"D6",3:"M",4:"M",5:"M",
      8:"M",9:"AB",10:"M",11:"M",12:"D6",
      15:"M",16:"D6",17:"M",18:"M",19:"M",
      22:"M",23:"D6",24:"M",25:"M",26:"M",
      29:"M",30:"D6"
    },
    tec002:{
      1:"D6",3:"M",4:"D6",5:"M",
      8:"D6",10:"M",11:"D6",12:"M",
      15:"D6",17:"M",18:"D6",19:"M",
      22:"D6",24:"M",25:"D6",26:"M",
      29:"D6"
    },
    tec003:{
      1:"T",2:"T",3:"T",4:"T",5:"T",
      8:"T",9:"T",10:"T",11:"T",12:"T",
      15:"T",16:"T",17:"T",18:"T",19:"T",
      22:"T",23:"T",24:"T",25:"T",26:"T",
      29:"T",30:"T"
    },
  };
  Object.entries(tecEscalas).forEach(([id,diasMap])=>{
    Object.entries(diasMap).forEach(([d,code])=>{
      if(code) e[`${id}_${d}_m`]=code;
    });
  });

  // Ione Farias — Auxiliar de Enfermagem — Plantao Noturno 12x60
  [2,5,9,12,16,19,23,26,30].forEach(d=>{ e[`aux001_${d}_m`]="N"; });

  // Assistentes Administrativos — Seg a Sex 8h
  ["adm001","adm002"].forEach(id=>{
    for(let d=1;d<=dias;d++){
      const dow=getDOW(d,mes,ano);
      if(dow>=1&&dow<=5) e[`${id}_${d}_m`]="M";
    }
  });

  return e;
}

const initState=()=>({
  profs:PROFS_INIT.map(p=>({...p})),
  escala:buildEscalaInicial(),
  ocorrencias:[],trocas:[],alteracoes:[],
  mes:5,ano:2026,setor:"SRAS",filtroGrupo:"todos",
});

// ── UI helpers ───────────────────────────────────────────────────────────────
const inp=(val,onChange,extra={})=>(
  <input value={val||""} onChange={e=>onChange(e.target.value)}
    style={{border:"1px solid #cbd5e1",borderRadius:8,padding:"7px 10px",fontSize:13,width:"100%",boxSizing:"border-box",...extra}}/>
);
const sel=(val,onChange,opts,extra={})=>(
  <select value={val||""} onChange={e=>onChange(e.target.value)}
    style={{border:"1px solid #cbd5e1",borderRadius:8,padding:"7px 10px",fontSize:13,width:"100%",background:"#f8fafc",...extra}}>
    {opts.map(o=>Array.isArray(o)?<option key={o[0]} value={o[0]}>{o[1]}</option>:<option key={o}>{o}</option>)}
  </select>
);
function Lbl({children}){return <div style={{fontSize:11,fontWeight:700,color:"#475569",marginBottom:3}}>{children}</div>;}
function Row({label,children,half}){
  return <div style={{marginBottom:10,width:half?"calc(50% - 4px)":undefined}}>
    {label&&<Lbl>{label}</Lbl>}{children}
  </div>;
}
function Card({title,children,accent,color}){
  return <div style={{background:"#fff",border:`1px solid ${accent||"#e2e8f0"}`,borderRadius:12,padding:16,marginBottom:12}}>
    {title&&<div style={{fontWeight:700,fontSize:13,color:color||"#1e293b",marginBottom:10,borderBottom:"1px solid #f1f5f9",paddingBottom:6}}>{title}</div>}
    {children}
  </div>;
}
function Empty({icon,msg,sub}){return <div style={{textAlign:"center",padding:"60px 0",color:"#94a3b8"}}><div style={{fontSize:44,marginBottom:10}}>{icon}</div><div style={{fontWeight:700,fontSize:14}}>{msg}</div>{sub&&<div style={{fontSize:12,marginTop:4}}>{sub}</div>}</div>;}
function Pill({label,cor,corT}){return <span style={{background:cor,color:corT,borderRadius:20,padding:"2px 9px",fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{label}</span>;}
function StatusTag({status}){
  const cfg={pendente:{bg:"#fff7ed",c:"#c2410c",t:"⏳ Aguard. colega"},aguardando_gestor:{bg:"#eff6ff",c:"#1d4ed8",t:"📋 Aguard. gestor"},aprovado:{bg:"#dcfce7",c:"#15803d",t:"✅ Aprovada"},recusado_colega:{bg:"#fee2e2",c:"#dc2626",t:"❌ Rec. colega"},recusado_gestor:{bg:"#fee2e2",c:"#dc2626",t:"❌ Rec. gestor"}};
  const s=cfg[status]||cfg.pendente;
  return <span style={{background:s.bg,color:s.c,borderRadius:8,padding:"3px 10px",fontWeight:700,fontSize:11}}>{s.t}</span>;
}

export default function App(){
  const [s,setS]=useState(initState);
  const [view,setView]=useState("escala");
  const [editCellKey,setEditCellKey]=useState(null); // `${profId}_${dia}`
  const [editProfId,setEditProfId]=useState(null);   // gestor editando ficha
  const [modal,setModal]=useState(null);
  const [toast,setToast]=useState(null);
  const [loading,setLoading]=useState(false);
  const [aiText,setAiText]=useState("");
  const [colabId,setColabId]=useState("");
  const [ocForm,setOcForm]=useState({tipo:"act_cp",dia:"",obs:""});
  const [trocaForm,setTrocaForm]=useState({meuDia:"",coleaId:"",diaColega:"",motivo:""});
  const [showACT,setShowACT]=useState(false);
  const [showReg,setShowReg]=useState(false);
  const [subView,setSubView]=useState("oc");
  const [editProf,setEditProf]=useState(null); // cópia editável

  const toast2=(msg,tipo="ok")=>{setToast({msg,tipo});setTimeout(()=>setToast(null),3000);};
  const dias=getDIM(s.mes,s.ano);
  const profsFiltBase=s.profs.filter(p=>p.setor===s.setor);
  const profsFilt=profsFiltBase.filter(p=>{
    if(s.filtroGrupo==="medicos") return p.cargo==="Médico(a) Regulador(a)";
    if(s.filtroGrupo==="enfermeiros") return p.cargo==="Enfermeiro(a)";
    return true;
  });
  const pendOc=s.ocorrencias.filter(o=>o.status==="pendente");
  const pendTr=s.trocas.filter(t=>t.status==="pendente"||t.status==="aguardando_gestor");
  const totalPend=pendOc.length+pendTr.length;

  // contagens ACT
  function usoAno(pid,tk){return s.ocorrencias.filter(o=>o.profId===pid&&o.tipo===tk&&o.ano===s.ano&&o.status!=="recusado").length;}
  function usoMes(pid,tk){return s.ocorrencias.filter(o=>o.profId===pid&&o.tipo===tk&&o.mes===s.mes&&o.ano===s.ano&&o.status!=="recusado").length;}
  function trocasMes(pid){return s.trocas.filter(t=>(t.solId===pid||t.colId===pid)&&t.mes===s.mes&&t.ano===s.ano&&!["recusado_colega","recusado_gestor"].includes(t.status)).length;}

  // ── ESCALA: edição de célula ─────────────────────────────────────────────
  function setCelula(profId,dia,slot,code){
    const key=`${profId}_${dia}_${slot}`;
    setS(prev=>{
      const old=prev.escala[key]||"";
      const ne={...prev.escala};
      if(code==="") delete ne[key]; else ne[key]=code;
      let na=prev.alteracoes;
      if(old!==code){
        const p=prev.profs.find(x=>x.id===profId);
        na=[{id:Date.now(),data:`${String(dia).padStart(2,"0")}/${String(prev.mes+1).padStart(2,"0")}/${prev.ano}`,prof:p?.nome||profId,id_prof:profId,siape:p?.siape||p?.matricula||"",setor:p?.setor||"",de:SC[old]?.label||old||"–",para:SC[code]?.label||code||"–",registradoEm:new Date().toLocaleString("pt-BR"),origem:"Gestor"},...na];
      }
      return {...prev,escala:ne,alteracoes:na};
    });
    setEditCellKey(null);
  }

  // ── EDIÇÃO DA FICHA DO PROFISSIONAL (gestor) ─────────────────────────────
  function abrirEdicaoProf(p){
    setEditProf({...p});
    setEditProfId(p.id);
    setView("gestor_edita");
  }
  function salvarEdicaoProf(){
    if(!editProf) return;
    setS(prev=>({...prev,profs:prev.profs.map(p=>p.id===editProf.id?{...editProf}:p)}));
    toast2("Ficha atualizada com sucesso! ✅");
    setView("equipe");
    setEditProfId(null);
    setEditProf(null);
  }

  // ── GESTOR: alterar turno de TODO o mês ──────────────────────────────────
  function aplicarTurnoMes(profId,novoTurno){
    setS(prev=>{
      const ne={...prev.escala};
      for(let d=1;d<=dias;d++){
        const old_m=ne[`${profId}_${d}_m`]||"";
        // só altera dias que já tinham turno de trabalho (não D6 vazio)
        if(old_m&&old_m!=="D6"&&old_m!=="FE"&&old_m!=="LM"){
          ne[`${profId}_${d}_m`]=novoTurno;
        }
      }
      const p=prev.profs.find(x=>x.id===profId);
      const na=[{id:Date.now(),data:`${MESES[prev.mes]}/${prev.ano}`,prof:p?.nome||profId,siape:p?.siape||p?.matricula||"",setor:p?.setor||"",de:"Turno anterior",para:`Turno ${SC[novoTurno]?.label||novoTurno} (mês todo)`,registradoEm:new Date().toLocaleString("pt-BR"),origem:"Gestor — mudança de turno"},...prev.alteracoes];
      return {...prev,escala:ne,alteracoes:na};
    });
    toast2(`Turno alterado para ${SC[novoTurno]?.label} em todo o mês!`);
  }

  // ── FICHA ─────────────────────────────────────────────────────────────────
  function addProf(dados){
    setS(p=>({...p,profs:[...p.profs,{...dados,id:`p${Date.now()}`}]}));
    toast2("Profissional adicionado!");
  }
  function removeProf(id){
    setS(p=>({...p,profs:p.profs.filter(x=>x.id!==id)}));
    toast2("Removido.","warn");
  }

  const totalCode=(code)=>profsFilt.reduce((acc,p)=>{
    let n=0;
    for(let d=1;d<=dias;d++){if(s.escala[`${p.id}_${d}_m`]===code)n++;if(s.escala[`${p.id}_${d}_t`]===code)n++;}
    return acc+n;
  },0);

  function countDia(dia,slot,code){
    return profsFilt.filter(p=>(s.escala[`${p.id}_${dia}_${slot}`]||"")=== code).length;
  }

  // ── Ocorrências colaborador ────────────────────────────────────────────────
  function enviarOc(){
    if(!colabId||!ocForm.dia){toast2("Preencha todos os campos.","warn");return;}
    const p=s.profs.find(x=>x.id===colabId);
    const tipo=TODOS_TIPOS.find(t=>t.key===ocForm.tipo);
    if(tipo?.limiteAno&&usoAno(colabId,ocForm.tipo)>=tipo.limiteAno){toast2("Limite anual atingido.","warn");return;}
    if(tipo?.limiteMes&&usoMes(colabId,ocForm.tipo)>=tipo.limiteMes){toast2("Limite mensal atingido.","warn");return;}
    const oc={id:Date.now(),profId:colabId,profNome:p?.nome||"",siape:p?.siape||p?.matricula||"",setor:p?.setor||"",tipo:ocForm.tipo,tipoLabel:tipo?.label||ocForm.tipo,tipoCode:tipo?.code||null,dia:Number(ocForm.dia),mes:s.mes,ano:s.ano,obs:ocForm.obs,status:"pendente",precisaDoc:tipo?.precisaDoc||false,regra:tipo?.regra||"",enviadoEm:new Date().toLocaleString("pt-BR")};
    setS(prev=>({...prev,ocorrencias:[oc,...prev.ocorrencias]}));
    setOcForm({tipo:"act_cp",dia:"",obs:""});
    toast2("Enviado ao gestor! ✅");
  }

  function enviarTroca(){
    if(!colabId||!trocaForm.meuDia||!trocaForm.coleaId||!trocaForm.diaColega){toast2("Preencha todos os campos.","warn");return;}
    const sol=s.profs.find(p=>p.id===colabId);
    const col=s.profs.find(p=>p.id===trocaForm.coleaId);
    if(sol?.cargo!==col?.cargo){toast2(`Troca só entre mesma categoria: ${sol?.cargo} ≠ ${col?.cargo}.`,"warn");return;}
    if(trocasMes(colabId)>=2){toast2("Limite de 2 trocas/mês atingido.","warn");return;}
    const temTurno=s.escala[`${colabId}_${trocaForm.meuDia}_m`]||s.escala[`${colabId}_${trocaForm.meuDia}_t`];
    if(!temTurno){toast2("Você não tem turno nesse dia.","warn");return;}
    const t={id:Date.now(),solId:colabId,solNome:sol?.nome||"",solCargo:sol?.cargo||"",solSiape:sol?.siape||sol?.matricula||"",colId:trocaForm.coleaId,colNome:col?.nome||"",colCargo:col?.cargo||"",colSiape:col?.siape||col?.matricula||"",meuDia:Number(trocaForm.meuDia),diaCol:Number(trocaForm.diaColega),motivo:trocaForm.motivo,mes:s.mes,ano:s.ano,setor:sol?.setor||"",status:"pendente",criadaEm:new Date().toLocaleString("pt-BR"),confirmaCol:null,aprovadaGestor:null};
    setS(prev=>({...prev,trocas:[t,...prev.trocas]}));
    setTrocaForm({meuDia:"",coleaId:"",diaColega:"",motivo:""});
    toast2("Pedido enviado! Aguardando colega. ✅");
  }

  function respTroca(tid,aceitar){
    setS(prev=>({...prev,trocas:prev.trocas.map(t=>t.id===tid?{...t,status:aceitar?"aguardando_gestor":"recusado_colega",confirmaCol:new Date().toLocaleString("pt-BR")}:t)}));
    toast2(aceitar?"Aceita! Aguardando gestor.":"Recusada.",aceitar?"ok":"warn");
  }

  function resolverTroca(tid,aprovar){
    setS(prev=>{
      const tr=prev.trocas.find(t=>t.id===tid);if(!tr) return prev;
      let ne={...prev.escala},na=[...prev.alteracoes];
      if(aprovar){
        ["m","t"].forEach(slot=>{
          const k1=`${tr.solId}_${tr.meuDia}_${slot}`;
          const k2=`${tr.colId}_${tr.diaCol}_${slot}`;
          const v1=ne[k1]||"",v2=ne[k2]||"";
          if(v1){ne[k2]=v1;} else delete ne[k2];
          if(v2){ne[k1]=v2;} else delete ne[k1];
        });
        na=[{id:Date.now(),data:`Dia${tr.meuDia}↔${tr.diaCol}/${String(tr.mes+1).padStart(2,"0")}/${tr.ano}`,prof:`${tr.solNome}↔${tr.colNome}`,siape:`${tr.solSiape}↔${tr.colSiape}`,setor:tr.setor,de:"—",para:"Troca aprovada",registradoEm:new Date().toLocaleString("pt-BR"),origem:"Troca ACT"},...na];
      }
      return {...prev,trocas:prev.trocas.map(t=>t.id===tid?{...t,status:aprovar?"aprovado":"recusado_gestor",aprovadaGestor:new Date().toLocaleString("pt-BR")}:t),escala:ne,alteracoes:na};
    });
    toast2(aprovar?"Troca aprovada! ✅":"Recusada.",aprovar?"ok":"warn");
  }

  function resolverOc(id,aprovar){
    setS(prev=>{
      const oc=prev.ocorrencias.find(o=>o.id===id);if(!oc) return prev;
      let ne={...prev.escala},na=[...prev.alteracoes];
      if(aprovar&&oc.tipoCode){
        const key=`${oc.profId}_${oc.dia}_m`;
        const old=ne[key]||"";
        ne[key]=oc.tipoCode;
        na=[{id:Date.now(),data:`${String(oc.dia).padStart(2,"0")}/${String(oc.mes+1).padStart(2,"0")}/${oc.ano}`,prof:oc.profNome,siape:oc.siape||"",setor:oc.setor,de:SC[old]?.label||old||"–",para:SC[oc.tipoCode]?.label||oc.tipoCode,registradoEm:new Date().toLocaleString("pt-BR"),origem:oc.tipoLabel},...na];
      }
      return {...prev,ocorrencias:prev.ocorrencias.map(o=>o.id===id?{...o,status:aprovar?"aprovado":"recusado"}:o),escala:ne,alteracoes:na};
    });
    toast2(aprovar?"Aprovado! ✅":"Recusado.",aprovar?"ok":"warn");
  }

  async function gerarIA(){
    setLoading(true);setAiText("");
    const resumo=profsFilt.map(p=>{
      const cells=Array.from({length:dias},(_,i)=>{const c=s.escala[`${p.id}_${i+1}_m`]||"";return c?`${i+1}(${c})`:null;}).filter(Boolean);
      return `${p.nome}(${p.cargo.split("(")[0].trim()}):${cells.join(",")||"sem escala"}`;
    }).join("\n");
    try{
      const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:800,messages:[{role:"user",content:`Gestor SRAS/HU-UFS EBSERH. Analise escala ${MESES[s.mes]}/${s.ano} e dê sugestões práticas em bullet points pt-BR:\n${resumo}`}]})});
      const data=await resp.json();
      setAiText(data.content?.[0]?.text||"Sem resposta.");
    }catch{setAiText("Erro ao consultar IA.");}
    setLoading(false);
  }

  const navItems=[
    ["escala","📋 Escala",false],
    ["portal","👤 Colaborador",false],
    ["pendencias",`✅ Pendências${totalPend?` (${totalPend})`:""}`,totalPend>0],
    ["equipe","👥 Equipe",false],
    ["alteracoes","🔄 Alterações",false],
    ["relatorio","📊 Relatório",false],
  ];

  const minhaCargo=s.profs.find(p=>p.id===colabId)?.cargo||"";
  const colegas=s.profs.filter(p=>p.id!==colabId&&p.cargo===minhaCargo);
  const tipoSel=TODOS_TIPOS.find(t=>t.key===ocForm.tipo);

  // ── render célula da escala ───────────────────────────────────────────────
  function renderCel(p,dia){
    const codeM=s.escala[`${p.id}_${dia}_m`]||"";
    const codeT=s.escala[`${p.id}_${dia}_t`]||"";
    const cellKey=`${p.id}_${dia}`;
    const isEd=editCellKey===cellKey;
    const stM=SC[codeM]||SC[""];
    const stT=SC[codeT]||SC[""];
    return (
      <td key={dia} style={{padding:"1px",textAlign:"center",position:"relative",minWidth:28}}>
        <div onClick={()=>setEditCellKey(isEd?null:cellKey)} style={{cursor:"pointer",display:"flex",flexDirection:"column",gap:1}}>
          <div style={{background:codeM?stM.bg:"#f8fafc",color:stM.text,borderRadius:3,padding:"1px 2px",fontSize:9,fontWeight:700,minWidth:22,textAlign:"center",lineHeight:"13px",border:`1px solid ${codeM?stM.text+"30":"#e2e8f0"}`}}>
            {codeM||"·"}
          </div>
          {codeT&&<div style={{background:stT.bg,color:stT.text,borderRadius:3,padding:"1px 2px",fontSize:9,fontWeight:700,minWidth:22,textAlign:"center",lineHeight:"13px",border:`1px solid ${stT.text}30`}}>{codeT}</div>}
        </div>
        {isEd&&(
          <div onClick={e=>e.stopPropagation()} style={{position:"absolute",zIndex:40,top:18,left:"-60px",background:"#fff",border:"2px solid #2563eb",borderRadius:12,padding:10,boxShadow:"0 8px 32px #0006",minWidth:230,display:"flex",flexDirection:"column",gap:6}}>
            <div style={{fontWeight:700,fontSize:11,color:"#1e3a8a",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span>☀️ Turno / Afastamento</span>
              <button onClick={()=>setEditCellKey(null)} style={{background:"none",border:"none",cursor:"pointer",fontSize:14,color:"#94a3b8"}}>✕</button>
            </div>
            <div style={{display:"flex",gap:3,flexWrap:"wrap"}}>
              {TODOS_CODIGOS.map(k=>{const v=SC[k];return(
                <button key={k} onClick={()=>setCelula(p.id,dia,"m",k)}
                  style={{background:v.bg,color:v.text,border:`2px solid ${codeM===k?v.text:"transparent"}`,borderRadius:5,padding:"3px 7px",fontSize:10,fontWeight:700,cursor:"pointer"}}>
                  {k}
                </button>
              );})}
              <button onClick={()=>setCelula(p.id,dia,"m","")} style={{background:"#fee2e2",color:"#dc2626",border:"none",borderRadius:5,padding:"3px 7px",fontSize:10,fontWeight:700,cursor:"pointer"}}>✕ limpar</button>
            </div>
            {/* Turno tarde/extra */}
            <div style={{borderTop:"1px solid #f1f5f9",paddingTop:5}}>
              <div style={{fontSize:10,color:"#64748b",fontWeight:600,marginBottom:3}}>🌆 2º turno (opcional)</div>
              <div style={{display:"flex",gap:3,flexWrap:"wrap"}}>
                {["T","M","D","N"].map(k=>{const v=SC[k];return(
                  <button key={k} onClick={()=>setCelula(p.id,dia,"t",k)}
                    style={{background:v.bg,color:v.text,border:`2px solid ${codeT===k?v.text:"transparent"}`,borderRadius:5,padding:"3px 7px",fontSize:10,fontWeight:700,cursor:"pointer"}}>
                    {k}
                  </button>
                );})}
                <button onClick={()=>setCelula(p.id,dia,"t","")} style={{background:"#f1f5f9",color:"#64748b",border:"none",borderRadius:5,padding:"3px 7px",fontSize:10,cursor:"pointer"}}>✕</button>
              </div>
            </div>
            <div style={{fontSize:9,color:"#94a3b8",borderTop:"1px solid #f1f5f9",paddingTop:4}}>
              {Object.entries(SC).filter(([k])=>k).map(([k,v])=><span key={k} style={{marginRight:6}}><b>{k}</b>={v.label}</span>)}
            </div>
          </div>
        )}
      </td>
    );
  }

  return (
    <div style={{fontFamily:"'Inter',system-ui,sans-serif",background:"#f0f4f8",minHeight:"100vh"}} onClick={()=>{if(editCellKey)setEditCellKey(null);}}>

      {/* HEADER */}
      <div style={{background:"linear-gradient(135deg,#1e3a8a,#2563eb)",color:"#fff",padding:"12px 20px"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
          <span style={{fontSize:22}}>🏥</span>
          <div>
            <div style={{fontWeight:800,fontSize:16}}>EscalaHosp <span style={{fontSize:10,opacity:.7,fontWeight:400}}>SRAS · HU-UFS · EBSERH · ACT 2024-2026</span></div>
            <div style={{fontSize:10,opacity:.8}}>Gestão completa de Escalas, Afastamentos e Trocas</div>
          </div>
          <div style={{marginLeft:"auto",display:"flex",gap:5,flexWrap:"wrap"}}>
            {navItems.map(([v,l,alerta])=>(
              <button key={v} onClick={()=>setView(v)}
                style={{background:view===v||view==="gestor_edita"&&v==="equipe"?"#fff":alerta?"#ef4444":"rgba(255,255,255,0.15)",color:view===v||view==="gestor_edita"&&v==="equipe"?"#1e3a8a":"#fff",border:"none",borderRadius:8,padding:"6px 11px",fontWeight:700,cursor:"pointer",fontSize:11}}>
                {l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* FILTROS */}
      <div style={{background:"#fff",borderBottom:"1px solid #e2e8f0",padding:"8px 20px",display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
        {["escala","relatorio","alteracoes","pendencias"].includes(view)&&(
          <select value={s.setor} onChange={e=>setS(p=>({...p,setor:e.target.value}))} style={{border:"1px solid #cbd5e1",borderRadius:8,padding:"6px 10px",fontWeight:700,fontSize:13,background:"#f8fafc",color:"#1e3a8a"}}>
            {SETORES.map(x=><option key={x}>{x}</option>)}
          </select>
        )}
        <select value={s.mes} onChange={e=>setS(p=>({...p,mes:+e.target.value}))} style={{border:"1px solid #cbd5e1",borderRadius:8,padding:"6px 10px",fontSize:13,background:"#f8fafc"}}>
          {MESES.map((m,i)=><option key={i} value={i}>{m}</option>)}
        </select>
        <select value={s.ano} onChange={e=>setS(p=>({...p,ano:+e.target.value}))} style={{border:"1px solid #cbd5e1",borderRadius:8,padding:"6px 10px",fontSize:13,background:"#f8fafc"}}>
          {[2024,2025,2026,2027].map(a=><option key={a}>{a}</option>)}
        </select>
        {view==="escala"&&(
          <div style={{display:"flex",gap:4}}>
            {[["todos","Todos"],["medicos","🩺 Médicos"],["enfermeiros","💉 Enfermeiros"]].map(([v,l])=>(
              <button key={v} onClick={()=>setS(p=>({...p,filtroGrupo:v}))} style={{background:s.filtroGrupo===v?"#1e3a8a":"#f8fafc",color:s.filtroGrupo===v?"#fff":"#475569",border:"1px solid #cbd5e1",borderRadius:8,padding:"5px 10px",fontWeight:700,cursor:"pointer",fontSize:11}}>{l}</button>
            ))}
          </div>
        )}
        <span style={{fontSize:11,color:"#1e3a8a",fontWeight:700}}>{MESES[s.mes]}/{s.ano}</span>
      </div>

      <div style={{padding:"14px 20px",maxWidth:1800,margin:"0 auto"}}>

        {/* ══ ESCALA ══ */}
        {view==="escala"&&(
          <div>
            <div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:10,alignItems:"center"}}>
              <span style={{fontSize:11,fontWeight:700,color:"#475569",marginRight:4}}>Legenda:</span>
              {Object.entries(SC).filter(([k])=>k).map(([k,v])=>(
                <span key={k} style={{background:v.bg,color:v.text,borderRadius:6,padding:"1px 6px",fontSize:9,fontWeight:700,border:`1px solid ${v.text}22`}}>{k}={v.label}</span>
              ))}
            </div>
            <div style={{fontSize:11,color:"#64748b",marginBottom:10}}>💡 Clique em qualquer célula para editar. Clique no nome do profissional para editar sua ficha (SIAPE, BH, CH, turno do mês).</div>

            {profsFilt.length===0?<Empty icon="📋" msg="Nenhum profissional" sub='Ajuste filtro ou vá em "Equipe"'/>:(
              <div style={{overflowX:"auto",borderRadius:12,border:"1px solid #e2e8f0",background:"#fff"}} onClick={e=>e.stopPropagation()}>
                <table style={{borderCollapse:"collapse",width:"100%",fontSize:10}}>
                  <thead>
                    <tr style={{background:"#1e3a8a",color:"#fff"}}>
                      <th style={{padding:"8px 10px",textAlign:"left",minWidth:170,position:"sticky",left:0,background:"#1e3a8a",zIndex:2,fontSize:11}}>Profissional ✏️</th>
                      <th style={{padding:"4px",minWidth:35,fontSize:9}}>CH</th>
                      <th style={{padding:"4px",minWidth:60,fontSize:9}}>Mat/SIAPE</th>
                      <th style={{padding:"4px",minWidth:50,fontSize:9}}>BH</th>
                      {Array.from({length:dias},(_,i)=>{
                        const dl=getDL(i+1,s.mes,s.ano);
                        const fim=dl==="Dom"||dl==="Sáb";
                        return <th key={i} style={{padding:"2px 1px",minWidth:28,textAlign:"center",background:fim?"#dc2626":"#1e3a8a",borderLeft:"1px solid #ffffff15"}}>
                          <div style={{fontSize:9}}>{i+1}</div>
                          <div style={{fontSize:7}}>{dl.slice(0,3)}</div>
                        </th>;
                      })}
                      <th style={{padding:"4px 6px",fontSize:9,minWidth:30}}>Dias</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Separadores por grupo */}
                    {["Médico(a) Regulador(a)","Enfermeiro(a)","Técnico(a) de Enfermagem","Auxiliar de Enfermagem","Assistente Administrativo"].map(cargo=>{
                      const grupo=profsFilt.filter(p=>p.cargo===cargo);
                      if(grupo.length===0) return null;
                      const bgGrp=cargo==="Médico(a) Regulador(a)"?"#1e3a8a":cargo==="Enfermeiro(a)"?"#0f766e":"#475569";
                      const lblGrp=cargo==="Médico(a) Regulador(a)"?"🩺 MÉDICOS REGULADORES":cargo==="Enfermeiro(a)"?"💉 ENFERMEIROS":cargo==="Técnico(a) de Enfermagem"?"🩹 TÉCNICOS DE ENFERMAGEM":"📋 ADMINISTRATIVOS";
                      return [
                        <tr key={`grp_${cargo}`}><td colSpan={dias+5} style={{background:bgGrp,color:"#fff",padding:"4px 12px",fontWeight:800,fontSize:10}}>{lblGrp} ({grupo.length})</td></tr>,
                        ...grupo.map((p,pi)=>{
                          let totalDias=0;
                          for(let d=1;d<=dias;d++){const c=s.escala[`${p.id}_${d}_m`]||"";if(c&&c!=="D6")totalDias++;}
                          const bgRow=pi%2===0?"#fff":"#f8fafc";
                          const bhNeg=p.bh&&p.bh.startsWith("-");
                          return (
                            <tr key={p.id} style={{background:bgRow,borderTop:"1px solid #e2e8f0"}}>
                              {/* Nome clicável para editar ficha */}
                              <td style={{padding:"5px 10px",position:"sticky",left:0,background:bgRow,zIndex:1,cursor:"pointer"}}
                                onClick={()=>abrirEdicaoProf(p)}>
                                <div style={{fontWeight:700,fontSize:10,color:"#1e3a8a",textDecoration:"underline dotted"}}>{p.nome}</div>
                                <div style={{fontSize:8,color:"#64748b"}}>{p.vinculo} · {p.cargo.split("(")[0].trim()}</div>
                              </td>
                              {/* CH editável inline */}
                              <td style={{padding:"2px 4px",textAlign:"center"}}>
                                <select value={p.ch||"36h"} onChange={e=>{setS(prev=>({...prev,profs:prev.profs.map(x=>x.id===p.id?{...x,ch:e.target.value}:x)}));}}
                                  style={{border:"1px solid #e2e8f0",borderRadius:5,padding:"1px 2px",fontSize:9,fontWeight:700,color:"#0f766e",background:"#f0fdf4",width:40}}>
                                  {CH_OPTS.map(o=><option key={o}>{o}</option>)}
                                </select>
                              </td>
                              {/* Matrícula/SIAPE editável inline */}
                              <td style={{padding:"2px 4px"}}>
                                <input value={p.siape||p.matricula||""} onChange={e=>{
                                  const val=e.target.value;
                                  setS(prev=>({...prev,profs:prev.profs.map(x=>x.id===p.id?{...x,siape:val,matricula:val}:x)}));
                                }} placeholder="SIAPE/Mat"
                                  style={{border:"1px solid #e2e8f0",borderRadius:5,padding:"1px 4px",fontSize:9,width:56,color:"#2563eb",fontWeight:600}}/>
                              </td>
                              {/* BH editável inline */}
                              <td style={{padding:"2px 4px"}}>
                                <input value={p.bh||""} onChange={e=>{
                                  const val=e.target.value;
                                  setS(prev=>({...prev,profs:prev.profs.map(x=>x.id===p.id?{...x,bh:val}:x)}));
                                }} placeholder="BH"
                                  style={{border:"1px solid #e2e8f0",borderRadius:5,padding:"1px 4px",fontSize:9,width:50,color:bhNeg?"#dc2626":"#15803d",fontWeight:700}}/>
                              </td>
                              {/* Células da escala */}
                              {Array.from({length:dias},(_,i)=>renderCel(p,i+1))}
                              <td style={{padding:"3px 6px",textAlign:"center",fontWeight:800,color:"#15803d",fontSize:10}}>{totalDias}</td>
                            </tr>
                          );
                        })
                      ];
                    })}
                    {/* TOTAIS por dia */}
                    {[["TOTAL MATUTINO (M)","#1e3a8a","m","M"],["TOTAL VESPERTINO (T)","#0f766e","m","T"],["TOTAL PLANTÃO DIA (D)","#854d0e","m","D"]].map(([lbl,bg,slot,code])=>(
                      <tr key={lbl} style={{background:bg,color:"#fff",fontWeight:700}}>
                        <td colSpan={4} style={{padding:"4px 12px",fontSize:9,position:"sticky",left:0,background:bg}}>{lbl}</td>
                        {Array.from({length:dias},(_,i)=>{
                          const n=profsFilt.filter(p=>(s.escala[`${p.id}_${i+1}_${slot}`]||"")=== code).length;
                          return <td key={i} style={{textAlign:"center",fontSize:9,padding:"2px 1px",background:n>0?"rgba(255,255,255,0.2)":undefined}}>{n||""}</td>;
                        })}
                        <td></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Cards resumo */}
            <div style={{display:"flex",gap:8,marginTop:12,flexWrap:"wrap"}}>
              {[["M","Manhãs","#1d4ed8"],["T","Tardes","#15803d"],["D","Plant.Dia","#854d0e"],["N","Plant.Noite","#6d28d9"],["FE","Férias","#15803d"],["F","Faltas","#b91c1c"],["D6","DSR","#64748b"],["AB","Abonos","#92400e"]].map(([k,l,c])=>(
                <div key={k} style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:10,padding:"6px 12px",textAlign:"center",minWidth:52}}>
                  <div style={{fontSize:18,fontWeight:800,color:c}}>{totalCode(k)}</div>
                  <div style={{fontSize:10,color:"#64748b"}}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ GESTOR EDITA FICHA ══ */}
        {view==="gestor_edita"&&editProf&&(
          <div style={{maxWidth:600,margin:"0 auto"}}>
            <div style={{background:"linear-gradient(135deg,#1e3a8a,#2563eb)",borderRadius:16,padding:20,color:"#fff",marginBottom:16}}>
              <div style={{fontWeight:800,fontSize:17}}>✏️ Edição de Ficha — Gestor</div>
              <div style={{fontSize:12,opacity:.85,marginTop:4}}>{editProf.nome}</div>
            </div>

            <Card title="Dados Pessoais e Funcionais" accent="#2563eb">
              <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
                <div style={{flex:"1 1 100%"}}>
                  <Lbl>Nome completo</Lbl>
                  {inp(editProf.nome,v=>setEditProf(p=>({...p,nome:v})))}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>SIAPE</Lbl>
                  {inp(editProf.siape,v=>setEditProf(p=>({...p,siape:v})),{borderColor:"#0d9488",borderWidth:2})}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Matrícula EBSERH</Lbl>
                  {inp(editProf.matricula,v=>setEditProf(p=>({...p,matricula:v})))}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>COREN / CRM</Lbl>
                  {inp(editProf.registro,v=>setEditProf(p=>({...p,registro:v})))}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Cargo</Lbl>
                  {sel(editProf.cargo,v=>setEditProf(p=>({...p,cargo:v})),CARGOS)}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Setor</Lbl>
                  {sel(editProf.setor,v=>setEditProf(p=>({...p,setor:v})),SETORES)}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Vínculo</Lbl>
                  {sel(editProf.vinculo,v=>setEditProf(p=>({...p,vinculo:v})),VINCULOS)}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Carga Horária</Lbl>
                  {sel(editProf.ch,v=>setEditProf(p=>({...p,ch:v})),CH_OPTS)}
                </div>
                <div style={{flex:"1 1 45%"}}>
                  <Lbl>Banco de Horas (BH)</Lbl>
                  {inp(editProf.bh,v=>setEditProf(p=>({...p,bh:v})),{borderColor:editProf.bh?.startsWith("-")?"#dc2626":"#16a34a",borderWidth:2,color:editProf.bh?.startsWith("-")?"#dc2626":"#15803d",fontWeight:700})}
                </div>
              </div>
            </Card>

            <Card title="🔄 Mudança de Turno — Mês Todo" accent="#0f766e" color="#0f766e">
              <div style={{fontSize:12,color:"#475569",marginBottom:10}}>Altera o turno principal de todos os dias trabalhados neste mês de uma vez.</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
                {["M","T","D","N"].map(k=>{const v=SC[k];return(
                  <button key={k} onClick={()=>{aplicarTurnoMes(editProf.id,k);toast2(`Turno alterado para ${v.label} em todo o mês!`);}}
                    style={{background:v.bg,color:v.text,border:`2px solid ${v.text}`,borderRadius:10,padding:"10px 4px",fontWeight:800,cursor:"pointer",fontSize:12}}>
                    {k}<br/><span style={{fontSize:9,fontWeight:400}}>{v.label}</span>
                  </button>
                );})}
              </div>
            </Card>

            <div style={{display:"flex",gap:10,marginTop:4}}>
              <button onClick={()=>{setView("equipe");setEditProf(null);}} style={{flex:1,border:"1px solid #cbd5e1",borderRadius:10,padding:12,cursor:"pointer",background:"#fff",fontWeight:600,fontSize:14}}>Cancelar</button>
              <button onClick={salvarEdicaoProf} style={{flex:2,background:"linear-gradient(135deg,#1e3a8a,#2563eb)",color:"#fff",border:"none",borderRadius:10,padding:12,cursor:"pointer",fontWeight:800,fontSize:14}}>💾 Salvar Alterações</button>
            </div>
          </div>
        )}

        {/* ══ PORTAL COLABORADOR ══ */}
        {view==="portal"&&(
          <div style={{maxWidth:620,margin:"0 auto"}}>
            <div style={{background:"linear-gradient(135deg,#0f766e,#0d9488)",borderRadius:16,padding:20,color:"#fff",marginBottom:16}}>
              <div style={{fontWeight:800,fontSize:17}}>👤 Portal do Colaborador — SRAS</div>
              <div style={{fontSize:12,opacity:.85,marginTop:4}}>Registre afastamentos e solicite trocas seguindo as regras do ACT EBSERH.</div>
            </div>

            <Card title="Quem é você?">
              <select value={colabId} onChange={e=>setColabId(e.target.value)} style={{width:"100%",border:"1px solid #cbd5e1",borderRadius:8,padding:"10px 12px",fontSize:14,background:"#f8fafc"}}>
                <option value="">— Selecione seu nome —</option>
                <optgroup label="🩺 Médicos Reguladores">{s.profs.filter(p=>p.cargo==="Médico(a) Regulador(a)").map(p=><option key={p.id} value={p.id}>{p.nome}</option>)}</optgroup>
                <optgroup label="💉 Enfermeiros">{s.profs.filter(p=>p.cargo==="Enfermeiro(a)").map(p=><option key={p.id} value={p.id}>{p.nome} | Mat: {p.matricula||"—"}</option>)}</optgroup>
                <optgroup label="🩹 Técnicos de Enfermagem">{s.profs.filter(p=>p.cargo==="Técnico(a) de Enfermagem").map(p=><option key={p.id} value={p.id}>{p.nome} | Mat: {p.matricula||"—"}</option>)}</optgroup>
                <optgroup label="🩺 Auxiliares de Enfermagem">{s.profs.filter(p=>p.cargo==="Auxiliar de Enfermagem").map(p=><option key={p.id} value={p.id}>{p.nome}</option>)}</optgroup>
                <optgroup label="📋 Assistentes Administrativos">{s.profs.filter(p=>p.cargo==="Assistente Administrativo").map(p=><option key={p.id} value={p.id}>{p.nome} | Mat: {p.matricula||"—"}</option>)}</optgroup>
              </select>
              {colabId&&(()=>{const p=s.profs.find(x=>x.id===colabId);return p?
                <div style={{marginTop:8,background:"#f0f9ff",border:"1px solid #bae6fd",borderRadius:8,padding:"8px 12px",fontSize:12,display:"flex",gap:12,flexWrap:"wrap",alignItems:"center"}}>
                  <b>{p.nome}</b>
                  <span style={{color:"#64748b"}}>{p.cargo.split("(")[0]}</span>
                  <span style={{color:"#0f766e",fontWeight:700}}>Mat: {p.matricula||"—"}</span>
                  <span style={{background:"#dcfce7",color:"#15803d",borderRadius:6,padding:"2px 8px",fontSize:11,fontWeight:700}}>Trocas: {trocasMes(colabId)}/2</span>
                </div>:null;})()}
            </Card>

            <div style={{display:"flex",gap:8,marginBottom:12}}>
              {[["oc","📋 Afastamento / Ocorrência"],["troca","🔄 Troca de Plantão"]].map(([v,l])=>(
                <button key={v} onClick={()=>setSubView(v)} style={{flex:1,background:subView===v?"#1e3a8a":"#fff",color:subView===v?"#fff":"#475569",border:"2px solid",borderColor:subView===v?"#1e3a8a":"#e2e8f0",borderRadius:10,padding:"10px",fontWeight:700,cursor:"pointer",fontSize:13}}>{l}</button>
              ))}
            </div>

            {subView==="oc"&&(
              <div>
                <div style={{background:"#fff7ed",border:"1px solid #fed7aa",borderRadius:12,padding:12,marginBottom:12}}>
                  <button onClick={()=>setShowACT(!showACT)} style={{background:"none",border:"none",cursor:"pointer",fontWeight:700,fontSize:13,color:"#c2410c",width:"100%",textAlign:"left",display:"flex",justifyContent:"space-between"}}>
                    📋 Meus direitos ACT EBSERH 2024-2026 <span>{showACT?"▲":"▼"}</span>
                  </button>
                  {showACT&&ACT_TIPOS[0].itens.map(t=>(
                    <div key={t.key} style={{background:t.cor,border:`1px solid ${t.corT}22`,borderRadius:8,padding:"8px 10px",marginBottom:6,marginTop:6}}>
                      <div style={{fontWeight:700,fontSize:12,color:t.corT}}>{t.label}{t.limiteAno?` — máx. ${t.limiteAno}/ano`:""}{t.limiteMes?` — máx. ${t.limiteMes}/mês`:""}</div>
                      <div style={{fontSize:11,color:"#475569",marginTop:2}}>{t.regra}</div>
                    </div>
                  ))}
                </div>
                <Card title="Tipo de afastamento">
                  {ACT_TIPOS.map(grupo=>(
                    <div key={grupo.grupo} style={{marginBottom:10}}>
                      <div style={{fontSize:11,fontWeight:800,color:"#475569",marginBottom:6,textTransform:"uppercase"}}>{grupo.grupo}</div>
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                        {grupo.itens.map(t=>{
                          const uA=colabId?usoAno(colabId,t.key):0;
                          const uM=colabId?usoMes(colabId,t.key):0;
                          const esg=(t.limiteAno&&uA>=t.limiteAno)||(t.limiteMes&&uM>=t.limiteMes);
                          return <button key={t.key} onClick={()=>!esg&&setOcForm(f=>({...f,tipo:t.key}))}
                            style={{background:ocForm.tipo===t.key?t.cor:esg?"#f1f5f9":"#fafafa",border:`2px solid ${ocForm.tipo===t.key?t.corT:esg?"#cbd5e1":"#e2e8f0"}`,borderRadius:10,padding:"8px",cursor:esg?"not-allowed":"pointer",fontWeight:700,fontSize:11,color:esg?"#94a3b8":ocForm.tipo===t.key?t.corT:"#475569",textAlign:"left",opacity:esg?.6:1}}>
                            <div>{t.label}</div>
                            {(t.limiteAno||t.limiteMes)&&colabId&&<div style={{fontSize:9,marginTop:2,fontWeight:400,color:esg?"#ef4444":"#94a3b8"}}>{t.limiteAno?`${uA}/${t.limiteAno}/ano`:""}{t.limiteMes?` ${uM}/${t.limiteMes}/mês`:""}{esg?" — ESGOTADO":""}</div>}
                          </button>;
                        })}
                      </div>
                    </div>
                  ))}
                </Card>
                {tipoSel&&<div style={{background:tipoSel.cor,border:`1px solid ${tipoSel.corT}33`,borderRadius:10,padding:"10px 14px",marginBottom:12}}>
                  <div style={{fontWeight:700,fontSize:12,color:tipoSel.corT}}>📌 Regra ACT: {tipoSel.regra}</div>
                  {tipoSel.precisaDoc&&<div style={{fontSize:11,color:"#dc2626",marginTop:4,fontWeight:600}}>⚠️ Necessita comprovante / declaração médica</div>}
                </div>}
                <Card title="Detalhes">
                  <Row label="Dia do mês *">{inp(ocForm.dia,v=>setOcForm(f=>({...f,dia:v})),{type:"number",min:1,max:dias})}</Row>
                  <Row label={tipoSel?.precisaDoc?"Nº Atestado / CID *":"Observação"}>
                    <textarea value={ocForm.obs} onChange={e=>setOcForm(f=>({...f,obs:e.target.value}))} rows={2} placeholder="Descreva..." style={{width:"100%",border:"1px solid #cbd5e1",borderRadius:8,padding:"9px 12px",fontSize:13,resize:"vertical",boxSizing:"border-box"}}/>
                  </Row>
                </Card>
                <button onClick={enviarOc} style={{width:"100%",background:"linear-gradient(135deg,#0f766e,#0d9488)",color:"#fff",border:"none",borderRadius:12,padding:14,fontWeight:800,fontSize:15,cursor:"pointer"}}>
                  📤 Enviar ao Gestor
                </button>
              </div>
            )}

            {subView==="troca"&&(
              <div>
                <div style={{background:"#eff6ff",border:"2px solid #3b82f6",borderRadius:12,padding:14,marginBottom:12}}>
                  <button onClick={()=>setShowReg(!showReg)} style={{background:"none",border:"none",cursor:"pointer",fontWeight:800,fontSize:13,color:"#1d4ed8",width:"100%",textAlign:"left",display:"flex",justifyContent:"space-between"}}>
                    📋 Regras de Troca — ACT EBSERH <span>{showReg?"▲":"▼"}</span>
                  </button>
                  {showReg&&["✅ Somente mesma categoria/cargo (ACT Cl.17)","✅ Ambos devem concordar","✅ Avisar gestor com 48h de antecedência","✅ Respeitar intervalo mínimo de 36h entre plantões","✅ Máximo 2 trocas/mês (norma HU-UFS)","✅ Gestor aprova — registro em log para auditoria"].map((r,i)=>(
                    <div key={i} style={{fontSize:12,color:"#1e293b",padding:"4px 0",borderBottom:"1px solid #dbeafe"}}>{r}</div>
                  ))}
                  {!showReg&&<div style={{fontSize:12,color:"#3b82f6",marginTop:4}}>Mesma categoria · máx. 2/mês · ambos concordam · gestor aprova</div>}
                </div>
                {colabId&&trocasMes(colabId)>=2&&<div style={{background:"#fee2e2",border:"1px solid #fca5a5",borderRadius:10,padding:"10px 14px",marginBottom:12,fontSize:12,color:"#dc2626",fontWeight:700}}>❌ Limite de 2 trocas neste mês atingido.</div>}
                <Card title="Dados da troca" accent="#3b82f6">
                  <Row label="📅 Dia SEU que quer trocar *">
                    {inp(trocaForm.meuDia,v=>setTrocaForm(f=>({...f,meuDia:v})),{type:"number",min:1,max:dias,border:"2px solid #3b82f6"})}
                    {trocaForm.meuDia&&colabId&&(()=>{const c=s.escala[`${colabId}_${trocaForm.meuDia}_m`];return c?<div style={{fontSize:11,color:"#15803d",marginTop:4,fontWeight:600}}>✅ Seu turno: {SC[c]?.label||c}</div>:<div style={{fontSize:11,color:"#dc2626",marginTop:4,fontWeight:600}}>⚠️ Sem turno nesse dia</div>;})()}
                  </Row>
                  <Row label={`👤 Colega para troca * (mesma categoria: ${minhaCargo||"—"})`}>
                    <select value={trocaForm.coleaId} onChange={e=>setTrocaForm(f=>({...f,coleaId:e.target.value}))} style={{width:"100%",border:"2px solid #3b82f6",borderRadius:8,padding:"9px 12px",fontSize:14,background:"#f8fafc"}}>
                      <option value="">— Selecione o colega —</option>
                      {colegas.map(p=><option key={p.id} value={p.id}>{p.nome} | Mat: {p.matricula||"—"}</option>)}
                    </select>
                    {colabId&&colegas.length===0&&<div style={{fontSize:11,color:"#f97316",marginTop:4}}>⚠️ Sem colegas da mesma categoria no sistema.</div>}
                  </Row>
                  <Row label="📅 Dia do COLEGA que você assumirá *">
                    {inp(trocaForm.diaColega,v=>setTrocaForm(f=>({...f,diaColega:v})),{type:"number",min:1,max:dias,border:"2px solid #3b82f6"})}
                    {trocaForm.diaColega&&trocaForm.coleaId&&(()=>{const c=s.escala[`${trocaForm.coleaId}_${trocaForm.diaColega}_m`];return c?<div style={{fontSize:11,color:"#15803d",marginTop:4,fontWeight:600}}>✅ Turno do colega: {SC[c]?.label||c}</div>:<div style={{fontSize:11,color:"#f97316",marginTop:4,fontWeight:600}}>⚠️ Colega sem turno nesse dia.</div>;})()}
                  </Row>
                  <Row label="Motivo (opcional)">
                    <textarea value={trocaForm.motivo} onChange={e=>setTrocaForm(f=>({...f,motivo:e.target.value}))} rows={2} placeholder="Descreva o motivo..." style={{width:"100%",border:"1px solid #cbd5e1",borderRadius:8,padding:"9px 12px",fontSize:13,resize:"vertical",boxSizing:"border-box"}}/>
                  </Row>
                </Card>
                <div style={{background:"#f0fdf4",border:"1px solid #bbf7d0",borderRadius:10,padding:"10px 14px",marginBottom:12,fontSize:11,color:"#15803d"}}>
                  <b>Fluxo:</b> Você solicita → Colega confirma aqui no portal → Gestor aprova → Escala atualizada ✅
                </div>
                <button onClick={enviarTroca} disabled={trocasMes(colabId)>=2} style={{width:"100%",background:trocasMes(colabId)>=2?"#94a3b8":"linear-gradient(135deg,#0369a1,#3b82f6)",color:"#fff",border:"none",borderRadius:12,padding:14,fontWeight:800,fontSize:15,cursor:trocasMes(colabId)>=2?"not-allowed":"pointer"}}>
                  🔄 Solicitar Troca de Plantão
                </button>

                {colabId&&s.trocas.filter(t=>t.solId===colabId||t.colId===colabId).length>0&&(
                  <Card title="Minhas trocas" accent="#e2e8f0">
                    {s.trocas.filter(t=>t.solId===colabId||t.colId===colabId).slice(0,5).map(t=>{
                      const souSol=t.solId===colabId;
                      return <div key={t.id} style={{padding:"10px 0",borderBottom:"1px solid #f1f5f9"}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8}}>
                          <div style={{flex:1}}>
                            <div style={{fontSize:12,fontWeight:700}}>{souSol?"Você → ":"De "}<b>{souSol?t.colNome:t.solNome}</b></div>
                            <div style={{fontSize:11,color:"#64748b"}}>Dia {t.meuDia} ↔ Dia {t.diaCol} — {MESES[t.mes]}/{t.ano}</div>
                          </div>
                          <StatusTag status={t.status}/>
                        </div>
                        {!souSol&&t.status==="pendente"&&(
                          <div style={{display:"flex",gap:8,marginTop:8}}>
                            <button onClick={()=>respTroca(t.id,true)} style={{flex:1,background:"#dcfce7",color:"#15803d",border:"1px solid #86efac",borderRadius:8,padding:"7px",fontWeight:700,cursor:"pointer",fontSize:12}}>✅ Aceitar</button>
                            <button onClick={()=>respTroca(t.id,false)} style={{flex:1,background:"#fee2e2",color:"#dc2626",border:"1px solid #fca5a5",borderRadius:8,padding:"7px",fontWeight:700,cursor:"pointer",fontSize:12}}>❌ Recusar</button>
                          </div>
                        )}
                      </div>;
                    })}
                  </Card>
                )}
              </div>
            )}
          </div>
        )}

        {/* ══ PENDÊNCIAS ══ */}
        {view==="pendencias"&&(
          <div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16,flexWrap:"wrap"}}>
              <div style={{fontWeight:800,fontSize:15,color:"#1e293b"}}>✅ Pendências do Gestor</div>
              {totalPend>0&&<Pill label={`${totalPend} pendente(s)`} cor="#fee2e2" corT="#dc2626"/>}
            </div>

            {pendTr.length>0&&(
              <div style={{marginBottom:20}}>
                <div style={{fontWeight:700,fontSize:13,color:"#1d4ed8",marginBottom:10}}>🔄 Trocas aguardando aprovação ({pendTr.length})</div>
                {s.trocas.filter(t=>t.status==="aguardando_gestor").map(t=>(
                  <div key={t.id} style={{background:"#fff",border:"2px solid #3b82f6",borderRadius:12,padding:16,marginBottom:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:10}}>
                      <div style={{flex:1}}>
                        <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap",marginBottom:8}}>
                          <span style={{fontWeight:800,fontSize:14}}>{t.solNome}</span>
                          <span style={{background:"#eff6ff",color:"#1d4ed8",borderRadius:6,padding:"1px 7px",fontWeight:700,fontSize:11}}>↔</span>
                          <span style={{fontWeight:800,fontSize:14}}>{t.colNome}</span>
                          <span style={{background:"#dcfce7",color:"#15803d",borderRadius:6,padding:"1px 7px",fontWeight:700,fontSize:11}}>✅ Colega confirmou</span>
                        </div>
                        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
                          {[{nome:t.solNome,cargo:t.solCargo,siape:t.solSiape,dia:t.meuDia,label:"SOLICITANTE"},{nome:t.colNome,cargo:t.colCargo,siape:t.colSiape,dia:t.diaCol,label:"COLEGA"}].map(x=>(
                            <div key={x.label} style={{background:"#f8fafc",borderRadius:8,padding:"8px 10px",border:"1px solid #e2e8f0"}}>
                              <div style={{fontSize:10,color:"#64748b",fontWeight:600}}>{x.label}</div>
                              <div style={{fontWeight:700,fontSize:13}}>{x.nome}</div>
                              <div style={{fontSize:11,color:"#64748b"}}>Cede dia <b>{x.dia}</b> · {x.cargo}</div>
                              <div style={{fontSize:10,color:"#94a3b8"}}>Mat/SIAPE: {x.siape||"—"}</div>
                            </div>
                          ))}
                        </div>
                        <div style={{background:"#eff6ff",borderRadius:8,padding:"6px 10px",fontSize:11,color:"#1d4ed8",marginBottom:4}}>
                          📋 Mesma categoria ✅ · Colega confirmou ✅ · Limite mensal verificado ✅
                        </div>
                        {t.motivo&&<div style={{fontSize:12,color:"#475569"}}>💬 {t.motivo}</div>}
                      </div>
                      <div style={{display:"flex",flexDirection:"column",gap:8,justifyContent:"center"}}>
                        <button onClick={()=>resolverTroca(t.id,true)} style={{background:"#dcfce7",color:"#15803d",border:"1px solid #86efac",borderRadius:8,padding:"8px 16px",fontWeight:700,cursor:"pointer"}}>✅ Aprovar</button>
                        <button onClick={()=>resolverTroca(t.id,false)} style={{background:"#fee2e2",color:"#dc2626",border:"1px solid #fca5a5",borderRadius:8,padding:"8px 16px",fontWeight:700,cursor:"pointer"}}>❌ Recusar</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {pendOc.length>0&&(
              <div>
                <div style={{fontWeight:700,fontSize:13,color:"#c2410c",marginBottom:10}}>📋 Afastamentos / Ocorrências ({pendOc.length})</div>
                {pendOc.map(o=>{
                  const tipo=TODOS_TIPOS.find(t=>t.key===o.tipo);
                  return <div key={o.id} style={{background:"#fff",border:"2px solid #fbbf24",borderRadius:12,padding:16,marginBottom:10,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:10}}>
                    <div style={{flex:1}}>
                      <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap",marginBottom:4}}>
                        <span style={{fontWeight:800,fontSize:14}}>{o.profNome}</span>
                        {o.siape&&<span style={{fontSize:11,color:"#2563eb",fontWeight:700,background:"#eff6ff",borderRadius:6,padding:"1px 7px"}}>Mat: {o.siape}</span>}
                        <Pill label={o.tipoLabel} cor={tipo?.cor||"#f1f5f9"} corT={tipo?.corT||"#475569"}/>
                        <span style={{fontSize:12,color:"#64748b"}}>Dia {String(o.dia).padStart(2,"0")}/{String(o.mes+1).padStart(2,"0")}/{o.ano}</span>
                      </div>
                      {tipo?.regra&&<div style={{fontSize:11,color:"#64748b",background:"#f8fafc",borderRadius:6,padding:"4px 8px",marginBottom:4}}>📌 {tipo.regra}</div>}
                      {o.obs&&<div style={{fontSize:12,color:"#475569"}}>💬 {o.obs}</div>}
                      {o.precisaDoc&&<div style={{fontSize:11,color:"#dc2626",fontWeight:700,marginTop:4}}>⚠️ Exige comprovante</div>}
                    </div>
                    <div style={{display:"flex",gap:8,alignItems:"center"}}>
                      <button onClick={()=>resolverOc(o.id,true)} style={{background:"#dcfce7",color:"#15803d",border:"1px solid #86efac",borderRadius:8,padding:"7px 14px",fontWeight:700,cursor:"pointer"}}>✅ Aprovar</button>
                      <button onClick={()=>resolverOc(o.id,false)} style={{background:"#fee2e2",color:"#dc2626",border:"1px solid #fca5a5",borderRadius:8,padding:"7px 14px",fontWeight:700,cursor:"pointer"}}>❌ Recusar</button>
                    </div>
                  </div>;
                })}
              </div>
            )}
            {totalPend===0&&<Empty icon="✅" msg="Nenhuma pendência" sub="As solicitações aparecerão aqui"/>}
          </div>
        )}

        {/* ══ EQUIPE ══ */}
        {view==="equipe"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
              <div>
                <div style={{fontWeight:800,fontSize:15,color:"#1e293b"}}>👥 Equipe ({s.profs.length})</div>
                <div style={{fontSize:11,color:"#64748b"}}>Clique em "✏️ Editar" para alterar SIAPE, BH, CH, cargo, turno e mais.</div>
              </div>
              <button onClick={()=>setModal("addProf")} style={{background:"#2563eb",color:"#fff",border:"none",borderRadius:8,padding:"8px 16px",fontWeight:700,cursor:"pointer"}}>+ Adicionar</button>
            </div>
            {["Médico(a) Regulador(a)","Enfermeiro(a)","Técnico(a) de Enfermagem","Auxiliar de Enfermagem","Assistente Administrativo"].map(cargo=>{
              const grp=s.profs.filter(p=>p.cargo===cargo);
              if(grp.length===0) return null;
              return <div key={cargo} style={{marginBottom:16}}>
                <div style={{fontWeight:800,fontSize:12,color:"#1e293b",marginBottom:8,padding:"5px 12px",background:"#f1f5f9",borderRadius:8}}>{cargo} ({grp.length})</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:8}}>
                  {grp.map(p=>(
                    <div key={p.id} style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:12,padding:14,display:"flex",justifyContent:"space-between",gap:8}}>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontWeight:700,color:"#1e293b",fontSize:13,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.nome}</div>
                        <div style={{fontSize:11,color:"#2563eb",marginTop:2}}>SIAPE: <b>{p.siape||"—"}</b> · Mat: <b>{p.matricula||"—"}</b></div>
                        {p.registro&&<div style={{fontSize:10,color:"#0f766e"}}>COREN/CRM: {p.registro}</div>}
                        <div style={{display:"flex",gap:8,marginTop:4,flexWrap:"wrap"}}>
                          <span style={{background:"#eff6ff",color:"#1d4ed8",borderRadius:6,padding:"1px 7px",fontSize:10,fontWeight:700}}>CH: {p.ch}</span>
                          <span style={{background:p.bh?.startsWith("-")?"#fee2e2":"#dcfce7",color:p.bh?.startsWith("-")?"#dc2626":"#15803d",borderRadius:6,padding:"1px 7px",fontSize:10,fontWeight:700}}>BH: {p.bh||"—"}</span>
                          <span style={{background:"#f3e8ff",color:"#7c3aed",borderRadius:6,padding:"1px 7px",fontSize:10,fontWeight:700}}>{p.vinculo}</span>
                        </div>
                      </div>
                      <div style={{display:"flex",flexDirection:"column",gap:4}}>
                        <button onClick={()=>abrirEdicaoProf(p)} style={{background:"#eff6ff",color:"#1d4ed8",border:"1px solid #bfdbfe",borderRadius:7,padding:"5px 10px",cursor:"pointer",fontWeight:700,fontSize:12,whiteSpace:"nowrap"}}>✏️ Editar</button>
                        <button onClick={()=>removeProf(p.id)} style={{background:"#fee2e2",color:"#dc2626",border:"none",borderRadius:7,padding:"5px 10px",cursor:"pointer",fontSize:12}}>✕</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>;
            })}
          </div>
        )}

        {/* ══ ALTERAÇÕES ══ */}
        {view==="alteracoes"&&(
          <div>
            <div style={{fontWeight:800,fontSize:15,color:"#1e293b",marginBottom:14}}>🔄 Log de Alterações</div>
            {s.alteracoes.length===0?<Empty icon="🔄" msg="Nenhuma alteração registrada"/>:(
              <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:12,overflow:"hidden"}}>
                <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
                  <thead><tr style={{background:"#f1f5f9"}}>{["Data","Profissional","Mat/SIAPE","Setor","De","Para","Origem","Em"].map(h=><th key={h} style={{padding:"9px 12px",textAlign:"left",fontWeight:700,color:"#475569",fontSize:11}}>{h}</th>)}</tr></thead>
                  <tbody>{s.alteracoes.map((a,i)=>(
                    <tr key={a.id} style={{borderTop:"1px solid #f1f5f9",background:i%2===0?"#fff":"#f8fafc"}}>
                      <td style={{padding:"7px 12px",fontWeight:600}}>{a.data}</td>
                      <td style={{padding:"7px 12px"}}>{a.prof}</td>
                      <td style={{padding:"7px 12px",color:"#0f766e",fontWeight:600}}>{a.siape||"—"}</td>
                      <td style={{padding:"7px 12px",color:"#2563eb",fontWeight:600}}>{a.setor}</td>
                      <td style={{padding:"7px 12px",fontSize:11,color:"#94a3b8"}}>{a.de}</td>
                      <td style={{padding:"7px 12px",fontSize:11,fontWeight:600}}>{a.para}</td>
                      <td style={{padding:"7px 12px",fontSize:11,color:"#7c3aed"}}>{a.origem||"Gestor"}</td>
                      <td style={{padding:"7px 12px",color:"#94a3b8",fontSize:10}}>{a.registradoEm}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ══ RELATÓRIO ══ */}
        {view==="relatorio"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14,flexWrap:"wrap",gap:8}}>
              <div style={{fontWeight:800,fontSize:15,color:"#1e293b"}}>📊 Relatório — {s.setor} | {MESES[s.mes]}/{s.ano}</div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={gerarIA} disabled={loading} style={{background:loading?"#94a3b8":"linear-gradient(135deg,#7c3aed,#2563eb)",color:"#fff",border:"none",borderRadius:8,padding:"8px 14px",fontWeight:700,cursor:loading?"default":"pointer",fontSize:13}}>
                  {loading?"⏳ Analisando...":"✨ Análise IA"}
                </button>
                <button onClick={()=>window.print()} style={{background:"#1e40af",color:"#fff",border:"none",borderRadius:8,padding:"8px 14px",fontWeight:700,cursor:"pointer",fontSize:13}}>🖨️ Imprimir</button>
              </div>
            </div>
            <div id="relatorio-print" style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:12,padding:24}}>
              <div style={{textAlign:"center",borderBottom:"2px solid #1e40af",paddingBottom:12,marginBottom:18}}>
                <div style={{fontWeight:800,fontSize:18,color:"#1e40af"}}>🏥 ESCALA DE TRABALHO — HU-UFS / EBSERH</div>
                <div style={{fontWeight:700,fontSize:14,color:"#1e293b",marginTop:3}}>SETOR DE REGULAÇÃO E AVALIAÇÃO EM SAÚDE (SRAS)</div>
                <div style={{color:"#64748b",fontSize:12}}>Núcleo Interno de Regulação · {MESES[s.mes]} / {s.ano}</div>
              </div>
              {["Médico(a) Regulador(a)","Enfermeiro(a)","Técnico(a) de Enfermagem","Auxiliar de Enfermagem","Assistente Administrativo"].map(cargo=>{
                const grp=profsFiltBase.filter(p=>p.cargo===cargo);
                if(grp.length===0) return null;
                return <div key={cargo} style={{marginBottom:20}}>
                  <div style={{fontWeight:800,fontSize:12,color:"#1e3a8a",marginBottom:8,padding:"4px 10px",background:"#eff6ff",borderRadius:6}}>
                    {cargo==="Médico(a) Regulador(a)"?"🩺 MÉDICOS REGULADORES":cargo==="Enfermeiro(a)"?"💉 ENFERMEIROS":cargo==="Técnico(a) de Enfermagem"?"🩹 TÉCNICOS ENFERMAGEM":cargo==="Auxiliar de Enfermagem"?"🩺 AUXILIARES ENFERMAGEM":"📋 ADMINISTRATIVOS"}
                  </div>
                  <div style={{overflowX:"auto"}}>
                    <table style={{width:"100%",borderCollapse:"collapse",fontSize:9}}>
                      <thead>
                        <tr style={{background:"#1e40af",color:"#fff"}}>
                          <th style={{padding:"5px 8px",textAlign:"left",minWidth:120}}>Profissional</th>
                          <th style={{padding:"5px 5px",minWidth:55}}>Mat/SIAPE</th>
                          <th style={{padding:"5px 4px",minWidth:25}}>CH</th>
                          <th style={{padding:"5px 4px",minWidth:40}}>BH</th>
                          {Array.from({length:dias},(_,i)=>{const dl=getDL(i+1,s.mes,s.ano);const fim=dl==="Dom"||dl==="Sáb";return <th key={i} style={{padding:"2px 1px",minWidth:22,background:fim?"#dc2626":"#1e40af",textAlign:"center"}}><div>{i+1}</div><div style={{fontSize:7}}>{dl.slice(0,2)}</div></th>;})}
                          <th style={{padding:"5px 4px"}}>Dias</th>
                        </tr>
                      </thead>
                      <tbody>
                        {grp.map((p,pi)=>{
                          let td=0;
                          return <tr key={p.id} style={{background:pi%2===0?"#fff":"#f8fafc",borderBottom:"1px solid #e2e8f0"}}>
                            <td style={{padding:"4px 8px",fontWeight:700}}>{p.nome}</td>
                            <td style={{padding:"4px 5px",color:"#0f766e",fontWeight:700,fontSize:8}}>{p.siape||p.matricula||"—"}</td>
                            <td style={{padding:"4px 4px",textAlign:"center",color:"#854d0e",fontWeight:700}}>{p.ch}</td>
                            <td style={{padding:"4px 4px",textAlign:"center",fontSize:8,color:p.bh?.startsWith("-")?"#dc2626":"#15803d",fontWeight:700}}>{p.bh||"—"}</td>
                            {Array.from({length:dias},(_,i)=>{
                              const c=s.escala[`${p.id}_${i+1}_m`]||"";
                              if(c&&c!=="D6")td++;
                              const st=SC[c]||SC[""];
                              return <td key={i} style={{padding:1,textAlign:"center",background:c?st.bg:"#fff",color:st.text,fontWeight:700,fontSize:8}}>{c||""}</td>;
                            })}
                            <td style={{padding:"4px 5px",textAlign:"center",fontWeight:800,color:"#15803d"}}>{td}</td>
                          </tr>;
                        })}
                        <tr style={{background:"#1e40af",color:"#fff",fontWeight:700}}>
                          <td colSpan={4} style={{padding:"3px 8px",fontSize:9}}>TOTAL MATUTINO</td>
                          {Array.from({length:dias},(_,i)=>{const n=grp.filter(p=>(s.escala[`${p.id}_${i+1}_m`]||"")==="M").length;return <td key={i} style={{textAlign:"center",fontSize:8}}>{n||""}</td>;})}
                          <td></td>
                        </tr>
                        <tr style={{background:"#0f766e",color:"#fff",fontWeight:700}}>
                          <td colSpan={4} style={{padding:"3px 8px",fontSize:9}}>TOTAL VESPERTINO</td>
                          {Array.from({length:dias},(_,i)=>{const n=grp.filter(p=>(s.escala[`${p.id}_${i+1}_m`]||"")==="T").length;return <td key={i} style={{textAlign:"center",fontSize:8}}>{n||""}</td>;})}
                          <td></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>;
              })}
              <div style={{marginTop:14,borderTop:"1px solid #e2e8f0",paddingTop:10,fontSize:10,color:"#94a3b8",textAlign:"right"}}>
                Gerado em: {new Date().toLocaleString("pt-BR")} · EscalaHosp · HU-UFS/EBSERH · ACT 2024-2026
              </div>
            </div>
            {aiText&&<div style={{marginTop:16,background:"linear-gradient(135deg,#f5f3ff,#eff6ff)",border:"1px solid #c4b5fd",borderRadius:12,padding:18}}>
              <div style={{fontWeight:700,color:"#6d28d9",marginBottom:8}}>✨ Análise IA</div>
              <div style={{fontSize:13,color:"#1e293b",whiteSpace:"pre-wrap",lineHeight:1.7}}>{aiText}</div>
            </div>}
          </div>
        )}
      </div>

      {modal==="addProf"&&<AddProfModal onAdd={(d)=>{addProf(d);setModal(null);}} onClose={()=>setModal(null)}/>}
      {toast&&<div style={{position:"fixed",bottom:20,right:20,background:toast.tipo==="warn"?"#f97316":"#22c55e",color:"#fff",padding:"11px 20px",borderRadius:10,fontWeight:700,fontSize:14,boxShadow:"0 4px 20px #0003",zIndex:999,maxWidth:340}}>{toast.msg}</div>}
      <style>{`@media print{body *{visibility:hidden}#relatorio-print,#relatorio-print *{visibility:visible}#relatorio-print{position:absolute;left:0;top:0;width:100%;padding:10px}}`}</style>
    </div>
  );
}

function AddProfModal({onAdd,onClose}){
  const [f,setF]=useState({nome:"",cargo:CARGOS[0],setor:SETORES[0],siape:"",matricula:"",registro:"",vinculo:"CLT/EBSERH",ch:"36h",bh:""});
  const u=(k,v)=>setF(p=>({...p,[k]:v}));
  return (
    <div style={{position:"fixed",inset:0,background:"#0008",zIndex:50,display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{background:"#fff",borderRadius:16,padding:26,width:"92%",maxWidth:460,boxShadow:"0 20px 60px #0003",maxHeight:"92vh",overflowY:"auto"}}>
        <div style={{fontWeight:800,fontSize:16,color:"#1e293b",marginBottom:18}}>➕ Novo Profissional</div>
        {[["nome","Nome completo *"],["matricula","Matrícula EBSERH"],["siape","SIAPE"],["registro","COREN / CRM"],["bh","Banco de Horas (ex: -005:30)"]].map(([k,l])=>(
          <div key={k} style={{marginBottom:10}}>
            <Lbl>{l}</Lbl>
            <input value={f[k]} onChange={e=>u(k,e.target.value)} style={{width:"100%",border:"1px solid #cbd5e1",borderRadius:8,padding:"8px 12px",fontSize:14,boxSizing:"border-box"}}/>
          </div>
        ))}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
          <div><Lbl>Vínculo</Lbl>{sel(f.vinculo,v=>u("vinculo",v),VINCULOS)}</div>
          <div><Lbl>Carga Horária</Lbl>{sel(f.ch,v=>u("ch",v),CH_OPTS)}</div>
        </div>
        <div style={{marginBottom:10}}><Lbl>Cargo</Lbl>{sel(f.cargo,v=>u("cargo",v),CARGOS)}</div>
        <div style={{marginBottom:16}}><Lbl>Setor</Lbl>{sel(f.setor,v=>u("setor",v),SETORES)}</div>
        <div style={{display:"flex",gap:10}}>
          <button onClick={onClose} style={{flex:1,border:"1px solid #cbd5e1",borderRadius:8,padding:10,cursor:"pointer",background:"#fff",fontWeight:600}}>Cancelar</button>
          <button onClick={()=>f.nome&&onAdd({...f,id:`p${Date.now()}`})} style={{flex:2,background:"#2563eb",color:"#fff",border:"none",borderRadius:8,padding:10,cursor:"pointer",fontWeight:700}}>Salvar</button>
        </div>
        {!f.nome&&<div style={{fontSize:11,color:"#f97316",textAlign:"center",marginTop:8}}>⚠️ Nome obrigatório</div>}
      </div>
    </div>
  );
}
